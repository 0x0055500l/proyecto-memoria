document.addEventListener('DOMContentLoaded', () => {

    const board = document.getElementById('game-board');
    const movesDisplay = document.getElementById('moves');
    const failsDisplay = document.getElementById('fails');
    const timerDisplay = document.getElementById('timer');
    const pairsFoundDisplay = document.getElementById('pairs-found');
    const totalPairsDisplay = document.getElementById('total-pairs');

    //sonido
    const winSound = new Audio("/static/sounds/win.mp3");
    const loseSound = new Audio("/static/sounds/lose.mp3");

    //modal
    const endGameModal = new bootstrap.Modal(document.getElementById('endGameModal'));
    const modalTitle = document.getElementById('modalTitle');
    const modalBody = document.getElementById('modalBody');
    const modalButton = document.getElementById('modalButton');

    const difficulty = board.dataset.difficulty;
    let cards = [];
    let hasFlippedCard = false;
    let lockBoard = false;
    let firstCard, secondCard;

    let isGameOver = false;

    let moves = 0;
    let fails = 0;
    let pairsFound = 0;
    let totalPairs = 0;
    let timer = 0;
    let timerInterval = null;

    // Configuración de niveles
    const difficultySettings = {
    	'basico': { pairs: 6, cols: 4, fails: 15 }, // 15 fallos máx
    	'medio': { pairs: 8, cols: 4, fails: 20 }, // 20 fallos máx
    	'avanzado': { pairs: 10, cols: 5, fails: 25 } // 25 fallos máx
    };
    let failLimit = 0;

    // Imágenes base (asegúrate de tenerlas en static/img/memory/)
    const baseImages = ['1.png', '2.png', '3.png', '4.png', '5.png', '6.png', '7.png', '8.png', '9.png', '10.png','11.jpg','12.jpg','13.jpg','14.jpg','15.jpg','16.jpg','17.jpg','18.jpg','19.jpg'];

    function startGame() {
        const config = difficultySettings[difficulty];
        totalPairs = config.pairs;
        failLimit = config.fails;

        board.style.gridTemplateColumns = `repeat(${config.cols}, 1fr)`;
        
        totalPairsDisplay.textContent = totalPairs;
        
        let gameImages = baseImages.slice(0, totalPairs);
        let cardData = [...gameImages, ...gameImages]; // Duplicar para tener pares
        
        shuffle(cardData);
        
        cardData.forEach(imageName => {
            const card = document.createElement('div');
            card.classList.add('card');
            card.dataset.name = imageName;
            
            card.innerHTML = `
                <div class="card-face card-front"></div>
                <div class="card-face card-back" style="background-image: url('/static/img/memory/${imageName}')"></div>
            `;
            
            board.appendChild(card);
            cards.push(card);
        });

        addCardListeners();
        startTimer();
    }
    
    function addCardListeners() {
        cards.forEach(card => card.addEventListener('click', flipCard));
    }

    function shuffle(array) {
        array.sort(() => Math.random() - 0.5);
    }

    function startTimer() {
        timerInterval = setInterval(() => {
            timer++;
            timerDisplay.textContent = `${timer}s`;
        }, 1000);
    }

    function flipCard() {
        if (lockBoard || isGameOver) return;
        if (this === firstCard) return;

        this.classList.add('is-flipped');

        if (!hasFlippedCard) {
            // Primer click
            hasFlippedCard = true;
            firstCard = this;
            return;
        }

        // Segundo click
        secondCard = this;
        lockBoard = true;
        
        updateCounters();
        checkForMatch();
    }

    function updateCounters() {
        moves++;
        movesDisplay.textContent = moves;
    }

    function checkForMatch() {
        let isMatch = firstCard.dataset.name === secondCard.dataset.name;
        isMatch ? disableCards() : unflipCards();
    }

    function disableCards() {
        // Es un par
        firstCard.removeEventListener('click', flipCard);
        secondCard.removeEventListener('click', flipCard);
        
        pairsFound++;
        pairsFoundDisplay.textContent = pairsFound;
        
        resetBoard();
        checkWinCondition();
    }

    function unflipCards() {
        // No es un par
        fails++;
        failsDisplay.textContent = fails;

        if (fails >= failLimit) {
        	endGame(false); // El jugador pierde
        }

        setTimeout(() => {
            firstCard.classList.remove('is-flipped');
            secondCard.classList.remove('is-flipped');
            resetBoard();
        }, 1000); // 1 segundo para memorizar
    }

    function resetBoard() {
        [hasFlippedCard, lockBoard] = [false, false];
        [firstCard, secondCard] = [null, null];
    }
    
    function checkWinCondition() {
        if (pairsFound === totalPairs) {
            clearInterval(timerInterval);
            //setTimeout(() => {
            //    alert(`¡Ganaste! \nMovimientos: ${moves} \nFallas: ${fails} \nTiempo: ${timer}s`);
            //    saveGameResult(true);
            //}, 500);
            endGame(true);
        }
    }
    
    function endGame(isWin) {
    if (isGameOver) return; // Evitar que se ejecute múltiples veces
    isGameOver = true;
    clearInterval(timerInterval);

    // Guardar el resultado en la BD (lo haremos asíncrono)
    saveGameResult(isWin);

    if (isWin) {
        // Lógica de Victoria
        winSound.play();
        modalTitle.textContent = "¡Felicidades! 🥳";
        modalBody.innerHTML = `
            Completaste el reto.
            <br><strong>Movimientos:</strong> ${moves}
            <br><strong>Fallas:</strong> ${fails}
            <br><strong>Tiempo:</strong> ${timer}s
        `;
    } else {
        // Lógica de Derrota
        loseSound.play();
        modalTitle.textContent = "¡Fin del Juego! 😢";
        modalBody.innerHTML = `
            Te quedaste sin intentos.
            <br><strong>Pares encontrados:</strong> ${pairsFound} / ${totalPairs}
            <br><strong>Tiempo:</strong> ${timer}s
        `;
    }
    
    // Mostrar el modal
    endGameModal.show();
}

// NUEVO: Añadir listener al botón del modal para redirigir
modalButton.addEventListener('click', () => {
    window.location.href = '/profile/'; // Redirigir al perfil al hacer clic
});

    async function saveGameResult(isWin) {
        const csrfToken = document.cookie.split('; ').find(row => row.startsWith('csrftoken='))?.split('=')[1];
        
        const dataToSend = {
            difficulty: difficulty,
            is_win: isWin,
            time_spent: timer,
            moves: moves,
            fails: fails
        };

        try {
            const response = await fetch('/save-game/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': csrfToken
                },
                body: JSON.stringify(dataToSend)
            });
            //if (response.ok) {
            //    window.location.href = '/profile/'; // Redirigir al perfil
            //}
            if (!response.ok) {
           	console.error('Error al guardar, pero el juego terminó de todos modos.');
            }
        } catch (error) {
            console.error('Error al guardar:', error);
        }
    }

    // Iniciar el juego
    startGame();
});
