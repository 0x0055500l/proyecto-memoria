from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from .models import Player, MemoryGame
import json

# --- Vistas de Autenticación (Reutilizadas) ---
def register_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            Player.objects.create(user=user) # Crea el perfil de jugador
            login(request, user)
            return redirect('home')
    else:
        form = UserCreationForm()
    return render(request, 'register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('login')

# --- Vistas del Perfil y Menú (Adaptadas) ---
@login_required
def home_view(request):
    return render(request, 'home.html')

@login_required
def profile_view(request):
    player = request.user.player
    # Buscamos el historial del juego de memoria
    game_history = MemoryGame.objects.filter(player=player).order_by('-date_played')
    context = {
        'player': player,
        'game_history': game_history
    }
    return render(request, 'profile.html', context)

# --- Vistas del Juego de Memoria (Nuevas) ---
@login_required
def memory_game_view(request, difficulty):
    context = {
        'difficulty': difficulty
    }
    return render(request, 'memory_game.html', context)

@login_required
def save_game_view(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            player = request.user.player

            MemoryGame.objects.create(
                player=player,
                difficulty=data['difficulty'][0].upper(),
                time_spent=data['time_spent'],
                moves=data['moves'],
                fails=data['fails'],
                is_win=data['is_win']
            )

            player.games_played += 1
            if data['is_win']:
                player.total_victories += 1
            else:
                player.total_defeats += 1
            player.save()

            return JsonResponse({'status': 'ok'})
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=400)
    return JsonResponse({'status': 'bad_request'}, status=400)
